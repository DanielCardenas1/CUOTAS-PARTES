CUENTAS PARTES - PAQUETE DE LIQUIDACIÓN (30 MESES)
    ==================================================

    Entidad: ALCAL PROVIDENCIA Y STA. CATALINA ISLAS (NIT: 800103021)
    Fecha de generación: 07/10/2025

    Contenido:
    - CONSOLIDADO_GLOBAL.pdf (resumen ejecutivo y totales)
    - PDFs individuales por pensionado (30 cuentas por persona)

    Alcance metodológico:
    - Sistema de 30 cuentas independientes (mes vencido)
    - Capital fijo por cuenta, sin capitalización entre meses
    - Intereses por DTF mensual específica
    - Primas en junio y diciembre según número de mesadas

    Resumen del paquete:
    - Pensionados incluidos: 1
    - Total de cuentas independientes: 30

    Observaciones:
    - Septiembre no se factura en este corte; ventana: últimos 30 meses hasta agosto de 2025.
    - Este paquete es de uso interno y soporte de cobro persuasivo.
